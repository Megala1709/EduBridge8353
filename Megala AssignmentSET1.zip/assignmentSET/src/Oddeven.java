//Any integer is input by the user .write a program to find out whether it is an odd number or even number
import java.util.Scanner;
public class Oddeven {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner scanner =new Scanner(System.in);
      System.out.println("Enter the Number");
      int num=scanner.nextInt();
      if(num%2==0)
    	  System.out.println("The Entered Number Is EVEN "+num);
      else
    	  System.out.println("The Entered Number Is ODD "+num);
      
	}

}
