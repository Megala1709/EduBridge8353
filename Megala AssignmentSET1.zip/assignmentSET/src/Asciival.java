import java.util.Scanner;
public class Asciival {

	public static void main(String[] args) {
		System.out.println("Enter the Character");
        Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		char ch=str.charAt(0);
		
     //convert character into ascii value using type converstion
		int asciiValue=(int)ch;
		//System.out.println("ASCII value of the charcater is "+asciiValue);
		if(asciiValue>=65&&asciiValue<=90)
				{
			        System.out.println("The Character Enterted is a CAPITAL LETTER");
				}
		else if(asciiValue>=97&&asciiValue<=122)
		{
			System.out.println("The Character Enterted is a SMALL LETTER");	
		}
		else if(asciiValue>=48&&asciiValue<=57)
		{
			System.out.println("The Character Enterted is a DIGITS");	
		}
		else if((asciiValue>=0&&asciiValue<=47)||(asciiValue>=58&&asciiValue<=64)||(asciiValue>=91&&asciiValue<=96)&&(asciiValue>=123&&asciiValue<=127))
		{
			System.out.println("The Character Enterted is a SPECIAL SYMBOL");	
		}
		else
		{
			System.out.println("Enterted Character is INVALID ");	
	}

}}
