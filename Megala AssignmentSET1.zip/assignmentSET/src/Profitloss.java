import java.util.Scanner;
public class Profitloss {
	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the Cost Price of the item");
		int costprice=scanner.nextInt();
		System.out.println("Enter the Selling Price of the item");
		int sellingprice=scanner.nextInt();
		if(sellingprice>costprice)
		{
			System.out.println("He get a profit");
			int profit=sellingprice-costprice;
			System.out.println("profit amount is "+profit);
		}
		else
			if(costprice>sellingprice)
			{
				System.out.println("He get a loss");
				int loss=costprice-sellingprice;
				System.out.println("Loss amount is "+loss);
			}
        
	}

}
