import java.util.Scanner;
public class Stdpercentage {
public static void main(String args[])
{
	Scanner scanner=new Scanner(System.in);
    System.out.println("Enter the student marks");
    System.out.println("Enter the tamil mark");
    int tamil=scanner.nextInt();
    System.out.println("Enter the english mark");
    int english=scanner.nextInt();
     System.out.println("Enter the maths mark");
    int maths=scanner.nextInt();
    System.out.println("Enter the science mark");
    int science=scanner.nextInt();
    System.out.println("Enter the sst mark");
    int sst=scanner.nextInt();
  int total=tamil+english+maths+science+sst;
  int percent=total/5;
  //System.out.println(percent);
  //System.out.println(total);
  if(percent>=60)
  {
	  System.out.println("FIRST DIVISION");
  }
  else if((percent>=50)&&(percent<=59))
  {
	  System.out.println("SECOND DIVISION");
  }
  else if((percent>=40)&&(percent<=49))
  {
	  System.out.println("THIRD DIVISION");
  }
  else 
  {
	  System.out.println("FAIL");
  }
    
}
}
