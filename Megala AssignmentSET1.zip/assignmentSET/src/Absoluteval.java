//Find the absolute value of a number entered by the user
import java.util.Scanner;
import java.lang.Math;
public class Absoluteval {
	public static void main(String[] args) {
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter The Number");
		int number=scanner.nextInt();
	    //using abs() function to this number
		int absval=Math.abs(number);
		System.out.println("The Absolute value for the number "+absval);
			}
}
