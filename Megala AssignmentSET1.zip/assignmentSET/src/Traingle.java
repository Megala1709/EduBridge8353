import java.util.Scanner;
public class Traingle {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the value of angle 1");
		int angle1=scanner.nextInt();
		System.out.println("Enter the value of angle 2");
		int angle2=scanner.nextInt();
		System.out.println("Enter the value of angle 3");
		int angle3=scanner.nextInt();
		int angle=angle1+angle2+angle3;
		if(angle==180)
		{
			System.out.println("valid Triangle");
		}
		else
		{
			System.out.println("Invalid Triangle");
		}

	}

}
