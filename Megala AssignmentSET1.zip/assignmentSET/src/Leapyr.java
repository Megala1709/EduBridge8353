import java.util.Scanner;
public class Leapyr {
	public static void main(String[] args) {
     Scanner scanner=new Scanner(System.in);
	 System.out.println("Enter the year");
	 int yr=scanner.nextInt();
	 if((yr%4==0)&&(yr%100==0)||(yr%400==0))
		 System.out.println("The year is LeapYear"+yr);
	 else
	     System.out.println("The Yeae is Not a LeapYear"+yr); 
  
	}

}
