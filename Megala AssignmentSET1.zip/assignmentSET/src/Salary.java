import java.util.Scanner;
public class Salary {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner scanner=new Scanner(System.in);
     System.out.println("Enter the salary amount");
     int salary=scanner.nextInt();
     float hra,da,grosssalary;
     if(salary<1500)
     {
    	  hra=salary/10;
    	  da= salary*90/100;
    	  grosssalary=salary+hra+da;
    	  System.out.println("hra"+hra);
    	  System.out.println("da"+da);
    	  System.out.println("The grosssalary is "+grosssalary);
     }
     else
     {
    	 hra=500;
    	 da=salary*98/100;
    	 grosssalary=salary+hra+da;
    	 System.out.println("hra"+hra);
   	  System.out.println("da"+da);
    	 System.out.println("The grosssalary is "+grosssalary);
     }
     
	}

}
