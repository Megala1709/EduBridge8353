import java.util.Scanner;
import java.util.Scanner;
public class YoungestAge {
public static void main(String[] args) {
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter the age of ram");
			int ramage=scanner.nextInt();
			System.out.println("Enter the age of sulabh");
			int sulabhage=scanner.nextInt();
			System.out.println("Enter the age of ajay");
			int ajayage=scanner.nextInt();
			if((ramage<sulabhage)&&(ramage<ajayage))
			{
				System.out.println("The  youngest one is RAM");
			}
			else if((sulabhage<ramage)&&(sulabhage<ajayage))
			{
				System.out.println("The  youngest one is SULABH");
			}
			else
				System.out.println("The  youngest one is AJAY");
		}

	}



