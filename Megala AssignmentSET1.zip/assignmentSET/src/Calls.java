import java.util.Scanner;;
public class Calls {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the number of calls");
		int calls=scanner.nextInt();
		double telebill,fsttelebill=0;
		double balcalls;
		if(calls>=0&&calls<=100)
		{
		  telebill=200;
			System.out.println("Monthly telephone billing amount "+telebill);
		}
		else if(calls>=101&&calls<=150)
		{
			calls=calls-100;
			telebill=200+(calls*0.6);
			System.out.println("Monthly telephone billing amount "+telebill);
		}
		else if(calls>=151&&calls<=200)
		{
			calls=calls-150;
			telebill=200+(50*0.6)+(calls*0.5);
			System.out.println("Monthly telephone billing amount "+telebill);
		}
		else if(calls>200)
				{
			calls=calls-200;
			telebill=200+(50*0.6)+(50*0.5)+(calls*0.4);
			System.out.println("Monthly telephone billing amount "+telebill);
				}
		else
		{  telebill=200;
			System.out.println("Monthly telephone billing amount "+telebill);	
		}
	}

}
