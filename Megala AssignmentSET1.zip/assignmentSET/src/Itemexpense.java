//Write the program to calculate the total expense ,quantity and price per item are input by the user and discount of 10% is offered 
//if the expense is more than 5000
import java.util.Scanner;
public class Itemexpense {
    public static void main(String[] args) {
    	Scanner scanner=new Scanner(System.in);
    	System.out.println("Enter the Quantity Of the Item");
		int quantity=scanner.nextInt();
		System.out.println("Enter the Price of the item");
		float price=scanner.nextFloat();
		float totalExpense=quantity*price;
        if(totalExpense>=5000)
        {
        	 totalExpense=totalExpense-(totalExpense/10);
        	System.out.println("The Total Expense is"+totalExpense);
        }
        else
        {
        	System.out.println("The Total Expense is"+totalExpense);	
        }
	}
}
