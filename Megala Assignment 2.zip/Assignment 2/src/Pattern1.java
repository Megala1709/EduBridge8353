public class Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//creating a row 
		int k=0;
		for(int i=1;i<=4;i++)
		{ 
			//System.out.print(i);
			for(int j=1;j<=i;j++)
			{   
				k++;
				System.out.print(2*i-j);
			}
		
			System.out.println();
		}

	}

}
