
public class Pattern4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=3;i++)
		{
			for(int k=3;k>i;k--)
			{
				System.out.print(" ");
			}
        for(int j=1;j<=i*2-1;j++)
        {
        	System.out.print("*");
        }
        
        System.out.println();
		}
		for(int s=2;s>=1;s--)
		{
			for(int n=3;n>s;n--)
			{
				System.out.print(" ");
			}
		for(int l=1;l<=s*2-1;l++)
        {
        	System.out.print("*");	
        }
		System.out.println();
		}
	}

}
